package com.example.nac_2_alarme;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
public class Alertar extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        NotificarSuporte NotificarSuporte = new NotificarSuporte(context);
        NotificationCompat.Builder nb = NotificarSuporte.getChannelNotification();
        NotificarSuporte.getManager().notify(1, nb.build());
    }
}